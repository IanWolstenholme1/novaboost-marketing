# NovaBoost Marketing

AI-Managed Marketing Agency Website

- Frontend in `/frontend`
- Backend in `/server`

Deploy Frontend to Vercel, Backend to Render.